This is the patch for truezip(http://truezip.java.net) ZipDriver.

usage:
  - use system property "de.schlichtherle.truezip.fs.archive.zip.ZIP_CHARSET" to
    set the default charset of truezip "ZipDriver"'s charset.
    * for example : -Dde.schlichtherle.truezip.fs.archive.zip.ZIP_CHARSET=GBK
  - OR use the environment variable "TRUEZIP_ZIP_CHARSET",
    * for example : set TRUEZIP_ZIP_CHARSET=GBK

2012/12/09, http://www.thinkbase.net.
for DocFetcher-1.1.5 (http://docfetcher.sourceforge.net/) .